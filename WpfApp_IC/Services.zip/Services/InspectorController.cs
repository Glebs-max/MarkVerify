﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace WpfApp_IC.Services
{
    public class InspectorController : IDisposable
    {
        private readonly ModbusService _modbus;
        private readonly CameraService _camera;
        private readonly IExpectedCodesService _expectedCodes;

        private CancellationTokenSource _cts;

        public int RejectDelayMs { get; set; } = 500;

        private int _stableSignal = -1;
        private int _previousSignal = -1;
        private int _sameCount = 0;
        private const int FILTER_COUNT = 3;

        private bool _triggerInProgress = false;

        public event Action<int> SignalChanged;
        public event Action<DataMatrixResult> DataMatrixRead;
        public event Action<string> ErrorOccurred;
        public event Action<BitmapSource> FrameReceived;

        // ВАЖНО: правильное объявление события
        public event Action<string, string?, bool> CodeChecked;


        public InspectorController(ModbusService modbus, CameraService camera, IExpectedCodesService expectedCodes)
        {
            _modbus = modbus;
            _camera = camera;
            _expectedCodes = expectedCodes;
        }


        public void Start()
        {
            _camera?.Open();
            _modbus?.Connect();

            _stableSignal = -1;
            _previousSignal = -1;
            _sameCount = 0;
            _triggerInProgress = false;

            _cts = new CancellationTokenSource();
            var token = _cts.Token;

            Task.Run(() => Loop(token), token);
        }


        private async Task Loop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    int rawSignal = _modbus.ReadSignal();

                    if (rawSignal == _stableSignal)
                    {
                        _sameCount++;
                    }
                    else
                    {
                        _sameCount = 0;
                        _stableSignal = rawSignal;
                    }

                    if (_sameCount >= FILTER_COUNT)
                    {
                        if (_stableSignal != _previousSignal)
                        {
                            _previousSignal = _stableSignal;
                            SignalChanged?.Invoke(_stableSignal);

                            if (_stableSignal == 1 && !_triggerInProgress)
                            {
                                _triggerInProgress = true;

                                var (dm, frame) = _camera.TriggerAndRead();

                                if (frame != null)
                                    FrameReceived?.Invoke(frame);

                                HandleDataMatrix(dm);
                            }

                            if (_stableSignal == 0)
                            {
                                _triggerInProgress = false;
                            }
                        }
                    }

                    await Task.Delay(50, token);
                }
                catch (Exception ex)
                {
                    ErrorOccurred?.Invoke(ex.Message);
                }
            }
        }


        private void HandleDataMatrix(DataMatrixResult dm)
        {
            string? expected = _expectedCodes.Peek();

            if (dm == null)
            {
                CodeChecked?.Invoke("<NO READ>", expected, false);
                ErrorOccurred?.Invoke("DataMatrix not read, activating rejector");

                RejectWithDelay();
                return;
            }

            bool ok = expected != null && dm.Normalized == expected;

            CodeChecked?.Invoke(dm.Normalized, expected, ok);

            if (!ok)
            {
                ErrorOccurred?.Invoke("DataMatrix mismatch, activating rejector");
                RejectWithDelay();
            }
            else
            {
                _expectedCodes.Dequeue();
            }

            DataMatrixRead?.Invoke(dm);
        }


        private void RejectWithDelay()
        {
            _ = Task.Run(async () =>
            {
                await Task.Delay(RejectDelayMs);
                _modbus.ActivateRejector();
            });
        }


        public void Stop()
        {
            _cts?.Cancel();

            _camera.Close();
            _modbus.Disconnect();
        }


        public void Dispose()
        {
            Stop();
            _modbus?.Dispose();
            _camera?.Dispose();
        }
    }
}
