﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_IC.Services
{
    public interface IExpectedCodesService
    {
        void Load(IEnumerable<string> codes);
        string? Peek();
        string? Dequeue();
        bool HasCodes { get; }
    }

    public class ExpectedCodesService : IExpectedCodesService
    {
        private readonly Queue<string> _queue = new Queue<string>();

        public void Load(IEnumerable<string> codes)
        {
            _queue.Clear();
            foreach (var c in codes)
                _queue.Enqueue(c);
        }

        public string? Peek() => _queue.Count > 0 ? _queue.Peek() : null;

        public string? Dequeue() => _queue.Count > 0 ? _queue.Dequeue() : null;

        public bool HasCodes => _queue.Count > 0;
    }
}
