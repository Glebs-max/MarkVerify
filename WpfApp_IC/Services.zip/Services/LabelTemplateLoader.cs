﻿using System.IO;
using System.Xml.Serialization;
using LabelDesigner;

namespace WpfApp_IC.Services
{
    public static class LabelTemplateLoader
    {
        public static DesignerViewModel Load(string path)
        {
            var serializer = new XmlSerializer(typeof(DesignerViewModel));
            using var stream = File.OpenRead(path);
            return (DesignerViewModel)serializer.Deserialize(stream);
        }
    }
}
